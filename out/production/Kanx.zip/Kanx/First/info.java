package First;

public interface info
{
    String college_name = "Manipal University Jaipur";

    void show();

    void calculate_performance();
}
